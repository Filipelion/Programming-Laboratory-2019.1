def create_graph():
    '''
    opens a file containing the entries
    :return: a tuple containing matrix, start and end
    '''
    file = open("input.txt", mode='r', encoding='utf-8-sig')
    n, start, end = map(lambda i: int(i), file.readline().split())  # fist line
    matrix = [[0 for i in range(n)] for j in range(n)]  # make a matrix of zeros

    for i in range(n - 1):
        a, b, c = map(lambda i: int(i), file.readline().split())  # n * lines
        matrix[a - 1][b - 1] = c  # (a, b) verse
        matrix[b - 1][a - 1] = c  # (b, a) inverse

    return (matrix, start - 1, end - 1)


def dijkstra_algorithm(matrix_adj, start, end):
    """

    :param matrix_adj: matrix of adjacency's
    :param start: starting point
    :param end: ending point
    :return: shortest way
    """
    D = {str(i): float("INF") for i in range(len(matrix_adj))}
    D[str(start)] = 0  # starting with zero in dictionary
    L = [(0, start)]  # make a list starting with zero (cost, vertice)

    while L != []:  # while the list isn't empty
        cost, current_vertice = L.pop(0)  # return and remove
        for neighbor in range(len(matrix_adj)):  # walking the matrix_adj
            if matrix_adj[current_vertice][neighbor]:  # if true...
                if D[str(neighbor)] > (matrix_adj[current_vertice][neighbor] + cost):  # if dic(value)>matrix(value) + c
                    D[str(neighbor)] = matrix_adj[current_vertice][neighbor] + cost  # dic(value) = matrix(value) + c
                    L.append((D[str(neighbor)], neighbor))  # list gets tuple of dic(cost) and vertice
    return D[str(end)]


# main function
if __name__ == "__main__":
    matrix, start, end = create_graph()
    result = dijkstra_algorithm(matrix, start, end)
    print(result)
