def create_graph():
    file = open("input.txt", mode='r', encoding='utf-8-sig')
    n, start, end = map(lambda i: int(i), file.readline().split()) # fist line
    graph = [[] for j in range(n)]

    for j in range(n-1):
        a, b, dist = map(lambda i: int(i), file.readline().split())
        graph[a-1].append((b-1, dist))
        graph[b-1].append((a-1, dist))

    return (graph, start, end)

def find_path(graph, start, end):
    key = []
    visited = [None for i in range(len(graph))]

    for i in graph[start]:
        key.append(i)
        visited[i[0]] = 1
    vertex = key[0]

    key.pop(0)
    while vertex[0] != end:
        for i in graph[vertex[0]]:
            if visited[i[0]] is None:
                visited[i[0]] = 1
                key.append((i[0], vertex[1] + i[1]))
        vertex = key[0]
        key.pop(0)

    return vertex[1]



# main function
if __name__ == "__main__":
    x = create_graph()
    graph, start, end = x[0], x[1], x[2]
    output = find_path(graph, start - 1, end - 1)
    print(output)