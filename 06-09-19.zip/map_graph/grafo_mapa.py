def input_lines():
    map = {}
    aphabet = list('abcdefghijklmnopqrstuvwxyz')
    arq = open("input.txt", mode='r', encoding='utf-8-sig')
    f_count = int(arq.readline())  # fist line
    for i in range(f_count):
        if (i+1) != f_count:
            # lines from input
            map[aphabet[i]] = list(arq.readline().lower())[:-1]
        else:
            map[aphabet[i]] = list(arq.readline().lower())

    return map

def color_numbers(start_matrix):
    # return colors numbers
    final = []
    map = start_matrix
    colors_list = list(range(len(map)))
    color_map = {}

    for key in map:
        neighbors = set(color_map.get(val) for val in map[key])

        for color in range(len(map)):
            if colors_list[color] not in neighbors:
                color_map[key] = colors_list[color]


    num_colors = list(color_map.values())
    for i in range(len(num_colors)):
        if num_colors[i] not in final:
            final.append(num_colors[i])

    return len(final)

# main function
if __name__ == "__main__":
    start = input_lines()
    print('Color numbers: %d' % color_numbers(start))
