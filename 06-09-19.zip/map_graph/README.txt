1 - As entradas devem ser colocadas no arquivo 'input.txt'
2 - inserir na primeira linha o numero de nós
3 - insira as ligaçãos por ordem de maiores até o de menores ligações

Uma matriz:

6
0 1 0 1 1 0
1 0 1 0 0 1
0 1 0 0 0 1
1 0 0 0 0 0
1 0 0 0 0 1
0 1 1 0 1 0

Como deve ser a entrada:

6
bde
acf
bce
bf
af
a